Known issues: <https://github.com/PredictiveEcology/Biomass_borealDataPrep/issues>

version 1.5.4
=============

## dependency changes
* terra is now a dependency

## new features


## bug fixes
* Comment fixes
